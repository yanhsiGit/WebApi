﻿using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DanLeeWebApi.Data
{
    public class ApplicationRole : IdentityRole<Guid>
    {
        /// <summary>
        /// 角色的類型:u=user / s = system
        /// </summary>
        public string? RoleType { get; set; } = "u";
        /// <summary>
        /// 預設欄位,Asp.Net Core Identity 的固定值"IdentityUser"
        /// </summary>
        public string Discriminator { get; set; } = "ApplicationRole";

    }
}
