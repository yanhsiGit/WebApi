﻿using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Extensions.Identity.Core;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DanLeeWebApi.Data
{
    public class ApplicationUser : IdentityUser<Guid>
    {
        public ApplicationUser()
        {
        }

        public ApplicationUser(string userName) : base(userName)
        {
        }

        #region Asp.Net Core Identity 系統用,請勿隨意變更
        /// <summary>
        /// 預設欄位,Asp.Net Core Identity 的固定值"IdentityUser"
        /// </summary>
        public string Discriminator { get; set; } = "IdentityUser";

        #endregion


    }
}
