﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using DanLeeWebApi.Data;
using DanLeeWebApi.Entity;
using Microsoft.AspNetCore.Cors;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory;
using Microsoft.EntityFrameworkCore;

namespace DanLeeWebApi.Controllers
{
	[Route("api/[controller]")]
	[ApiController]
	public class ProductApiController : ControllerBase
	{
		private readonly ApplicationDbContext _context;

		public ProductApiController(ApplicationDbContext context)
		{
			_context = context;

		}

		/// <summary>
		/// 新增產品
		/// </summary>
		/// <returns></returns>
		[Route("getIP")]
		[HttpGet]
		public string getIP()
		{
			var remoteIpAddress = HttpContext.Connection.RemoteIpAddress.MapToIPv4().ToString();
			Console.WriteLine("My Ip => " + remoteIpAddress);

			return remoteIpAddress;

		}

		/// <summary>
		/// 查詢所有產品
		/// </summary>
		/// <returns></returns>
		[Route("QueryAllProduct")]
		[HttpGet]
		public List<categorys> QueryAllProduct()
		{
			var item = _context.categorys.ToList();

			return item;

		}

		/// <summary>
		/// 新增產品
		/// </summary>
		/// <returns></returns>
		[Route("AddProduct")]
		[HttpPost]
		public string AddProduct([FromBody] categorys Args)
		{
			try
			{
				if (Args != null)
				{
					categorys item = _context.categorys.FirstOrDefault((categorys x) => x.CategoryNo == Args.CategoryNo);
					//get amount 
					productcategorys amountList = _context.productcategorys.FirstOrDefault(x => x.CategoryName == Args.productCategory);
					if (item == null)
					{
						Args.createDate = DateTime.Now;
						
						_context.categorys.Add(Args);
						_context.SaveChanges();

						return "success";
					}
					else
					{
						item.createDate = DateTime.Now;
						item.applications = Args.applications;
						item.crossReactivity = Args.crossReactivity;
						item.source = Args.source;
						item.category = Args.category;
						item.CategoryName = Args.CategoryName;
						item.CategoryNo = Args.CategoryNo;
						item.productCategory = Args.productCategory;
						item.species = Args.species;
						
						_context.categorys.Update(item);
						_context.SaveChanges();

						return "success";
					}

				}
				else
				{
					return "failed";
				}
			}
			catch (Exception ex)
			{
				return "failed";
			}

		}

		

		/// <summary>
		/// 刪除產品
		/// </summary>
		/// <returns></returns>
		[Route("RemoveProduct/{categoryNo}")]
		[HttpPost]
		public string RemoveProduct([FromQuery] string categoryNo)
		{
			try
			{
				categorys item = _context.categorys.FirstOrDefault((categorys x) => x.CategoryNo == categoryNo);
				_context.categorys.Remove(item);
				_context.SaveChanges();

				return "success";
			}
			catch (Exception ex)
			{
				return "failed";
			}
		}

		/// <summary>
		/// 修改產品
		/// </summary>
		/// <returns></returns>
		[Route("UpdateProduct")]
		[HttpPost]
		public string UpdateProduct([FromBody] categorys data)
		{
			try
			{
				categorys item = _context.categorys.FirstOrDefault((categorys x) => x.CategoryNo == data.CategoryNo);
				_context.categorys.Update(item);
				_context.SaveChanges();

				return "success";
			}
			catch (Exception ex)
			{
				return "failed";
			}
		}
	}
}
