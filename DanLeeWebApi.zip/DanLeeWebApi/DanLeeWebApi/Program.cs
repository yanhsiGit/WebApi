using DanLeeWebApi.Data;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Mvc;
using Pomelo.EntityFrameworkCore.MySql;
using Microsoft.Extensions.Configuration;
using System.Globalization;
using Microsoft.AspNetCore.Localization;
using Microsoft.AspNetCore.Mvc.Razor;
using System.Text;
using System.Text.Encodings.Web;
using System.Text.Unicode;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;

using Microsoft.OpenApi.Models;
using Newtonsoft.Json.Serialization;
using Swashbuckle.AspNetCore.Swagger;
using System.Reflection;
using Microsoft.AspNetCore.Builder;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

// Add services to the container.
builder.Services.AddCors(o => o.AddPolicy("CorsPolicy", builder =>
{
	builder.AllowAnyOrigin()
		   .AllowAnyHeader()
		   .AllowAnyMethod();
}));

builder.Services.AddMemoryCache();
builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();

builder.Services.AddSwaggerGen(c =>
{
	var baseDirectory = AppDomain.CurrentDomain.BaseDirectory;
	
	var commentsFileName = Path.Combine(AppContext.BaseDirectory, "DanLeeWebApi.xml");
    var commentsFile = Path.Combine(baseDirectory, commentsFileName);

	c.IncludeXmlComments(commentsFile);

	c.SwaggerDoc(
		  // name: ���� SwaggerDocument �� URL ��m�C
		  name: "v1",
		  // info: �O�Ω� SwaggerDocument ������T�����(���e�D����)�C
		  info: new OpenApiInfo
		  {
			  Title = "DanLee Web API ���",
			  Version = "1.0.0",
			  Description = "DanLee Web API",

		  }
	  );


	c.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
	{
		Description =
"JWT Authorization header using the Bearer scheme. \r\n\r\n Enter 'Bearer' [space] and then your token in the text input below.\r\n\r\nExample: \"Bearer 12345abcdef\"",
		Name = "Authorization",
		In = ParameterLocation.Header,
		Type = SecuritySchemeType.ApiKey,
		Scheme = "Bearer"
	});

	c.AddSecurityDefinition("reCAPTCHA", new OpenApiSecurityScheme
	{
		Description =
"Google ReCaptcha",
		Name = "reCAPTCHA",
		In = ParameterLocation.Header,
		Type = SecuritySchemeType.ApiKey,
	});

	c.AddSecurityRequirement(new OpenApiSecurityRequirement()
				{
					{
						new OpenApiSecurityScheme
						{
							Reference = new OpenApiReference
							{
								Type = ReferenceType.SecurityScheme,
								Id = "Bearer"
							},
							Scheme = "oauth2",
							Name = "Bearer",
							In = ParameterLocation.Header,

						},
						new List<string>()
					}
				});

	c.AddSecurityRequirement(new OpenApiSecurityRequirement()
				{
					{
						new OpenApiSecurityScheme
						{
							Reference = new OpenApiReference
							{
								Type = ReferenceType.SecurityScheme,
								Id = "reCAPTCHA"
							},
							Scheme = "oauth2",
							Name = "reCAPTCHA",
							In = ParameterLocation.Header,

						},
						new List<string>()
					}
				});


});


//���oIP Accessor
builder.Services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();


builder.Services.AddMvc().SetCompatibilityVersion(CompatibilityVersion.Version_2_2)
	.ConfigureApiBehaviorOptions(options =>
	{
		// �������ҥ��Ѯɦ۰� HTTP 400 �^��
		options.SuppressModelStateInvalidFilter = true;
	}).AddJsonOptions(options =>
	{
		options.JsonSerializerOptions.Encoder = JavaScriptEncoder.Create(UnicodeRanges.All);
		options.JsonSerializerOptions.PropertyNamingPolicy = null;
	});

var connectionString = builder.Configuration.GetConnectionString("DefaultConnection");
builder.Services.AddDbContext<ApplicationDbContext>(options =>
  options.UseMySql(connectionString, ServerVersion.AutoDetect(connectionString)));



var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
	app.UseCors("CorsPolicy");
	app.UseDeveloperExceptionPage();
}

app.UseSwagger();
app.UseSwaggerUI(c =>
{
	c.SwaggerEndpoint(
		// url: �ݰt�X SwaggerDoc �� name�C "/swagger/{SwaggerDoc name}/swagger.json"
		url: "/swagger/v1/swagger.json",
		name: "DanLee Web Api"
	);

});

app.UseHttpsRedirection();

app.UseRouting();
app.UseCors("CorsPolicy");
app.UseAuthorization();


app.UseEndpoints(endpoints =>
{
	endpoints.MapControllers();
});

app.Run();
